import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.data.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class election_randomizer extends PApplet {

//////////////////////////////////////////
// 2016 ELECTION RESULT RANDOMIZER      //
// all values measured in HRC minus DJT //
//////////////////////////////////////////



float natl_stdev = 3.6f;
float northeast_stdev = 2;
float midwest_stdev = 3;
float west_stdev = 3;
float south_stdev = 2.2f;

PFont pts_font = createFont("asdf", 10);
PFont headline_font = createFont("Georgia-BoldItalic", 75);
PFont subheadline_font = createFont("Georgia-BoldItalic", 32);

String[] states = {
  "DC", "MD", "VT", "HI", "MA", "CA", "NY", "RI", "IL", "ME1", "WA", "DE", "NJ", "CT", "OR", "ME", "NM", "MN", "VA", "WI", "MI", "PA", "CO", "NH", "NV", "NC", "FL", "ME2", "OH", "AZ", "IA", "NE2", "GA", "SC", "AK", "TX", "MO", "UT", "IN", "TN", "KS", "MS", "MT", "LA", "SD", "NE1", "KY", "AR", "NE", "ID", "AL", "ND", "OK", "WV", "WY", "NE3"
};
int[] evs_array = {
  3, 10, 3, 4, 11, 55, 29, 4, 20, 1, 12, 3, 14, 7, 7, 2, 5, 10, 13, 10, 16, 20, 9, 4, 6, 15, 29, 1, 18, 11, 6, 1, 16, 9, 3, 38, 10, 6, 11, 11, 6, 6, 3, 8, 3, 1, 8, 6, 2, 4, 9, 3, 7, 5, 3, 1
};
IntDict evs = new IntDict();


FloatDict exps = new FloatDict();
FloatDict stdevs = new FloatDict();
FloatDict results = new FloatDict();
IntDict winner = new IntDict();        // 0=HRC, 1=DJT, 2=McM

int clinton_score;
int trump_score;
int mcmullin_score;

int time_counter;


public void gen_results() {
  // start with baseline from polls
  float[] exps_array = {
    70.6f, 26.4f, 26.2f, 24.3f, 22.3f, 22.2f, 19.0f, 13.2f, 12.6f, 12.5f, 12.1f, 12.0f, 11.3f, 10.9f, 8.5f, 6.0f, 5.5f, 5.0f, 4.9f, 4.2f, 4.0f, 3.4f, 3.2f, 1.9f, -0.2f, -0.2f, -0.2f, -1.1f, -2.3f, -3.5f, -3.5f, -4.2f, -4.8f, -7.1f, -7.6f, -9.7f, -11.2f, -11.3f, -12.1f, -13.3f, -13.4f, -15.1f, -16.1f, -16.6f, -17.1f, -17.7f, -19.0f, -20.0f, -20.1f, -21.3f, -22.0f, -23.7f, -27.1f, -27.4f, -37.2f, -38.5f
  };
  for (int i = 0; i < states.length; i++)
    exps.set(states[i], exps_array[i]);

  // adjust for national and regional polling error
  float natl_error = randomGaussian() * natl_stdev;
  float northeast_error = randomGaussian() * northeast_stdev;
  float midwest_error = randomGaussian() * midwest_stdev;
  float west_error = randomGaussian() * west_stdev;
  float south_error = randomGaussian() * south_stdev;

  String[] northeast = {
    "ME", "ME1", "ME2", "NH", "PA", "NY", "NJ", "MD", "MA", "VT", "CT", "DE", "RI"
  };
  String[] midwest = {
    "OH", "MI", "WI", "MN", "IA"
  };
  String[] west = {
    "CO", "NV", "AZ", "CA", "OR", "WA"
  };
  String[] south = {
    "VA", "NC", "GA", "FL", "SC", "LA", "MS", "AL"
  };

  for (int i = 0; i < northeast.length; i++)
    exps.set(northeast[i], exps.get(northeast[i]) + northeast_error);
  for (int i = 0; i < midwest.length; i++)
    exps.set(midwest[i], exps.get(midwest[i]) + midwest_error);
  for (int i = 0; i < west.length; i++)
    exps.set(west[i], exps.get(west[i]) + west_error);
  for (int i = 0; i < south.length; i++)
    exps.set(south[i], exps.get(south[i]) + south_error);
  for (int i = 0; i < states.length; i++)
    exps.set(states[i], exps.get(states[i]) + natl_error);

  // adjust for state polling error
  float[] stdevs_array = {
    7.2f, 6.8f, 11.2f, 10, 6.6f, 6.0f, 6.0f, 9.9f, 6.0f, 10.3f, 6.6f, 9.5f, 6.5f, 7, 6.8f, 8.4f, 7.1f, 6.6f, 6.2f, 6.4f, 6.3f, 6.3f, 6.5f, 7.7f, 6.7f, 6.0f, 6.0f, 11.6f, 6.3f, 6.9f, 7.1f, 13.3f, 6.0f, 6.0f, 11.5f, 6.0f, 6.0f, 6.7f, 6.0f, 6.3f, 6.4f, 6.3f, 9.0f, 5.7f, 10.0f, 13.0f, 5.8f, 6.4f, 8.1f, 7.2f, 6.5f, 10.3f, 6.5f, 8.0f, 12.5f, 11.8f
  };
  // i made these too high oops (fixed below)
  for (int i = 0; i < stdevs_array.length; i++)
    stdevs_array[i] = stdevs_array[i] * 0.8f;
  for (int i = 0; i < states.length; i++)
    stdevs.set(states[i], stdevs_array[i]);

  for (int i = 0; i < northeast.length; i++)
    stdevs.set(northeast[i], sqrt(pow(stdevs.get(northeast[i]), 2) - pow(northeast_stdev, 2)));
  for (int i = 0; i < midwest.length; i++)
    stdevs.set(midwest[i], sqrt(pow(stdevs.get(midwest[i]), 2) - pow(midwest_stdev, 2)));
  for (int i = 0; i < west.length; i++)
    stdevs.set(west[i], sqrt(pow(stdevs.get(west[i]), 2) - pow(west_stdev, 2)));
  for (int i = 0; i < south.length; i++)
    stdevs.set(south[i], sqrt(pow(stdevs.get(south[i]), 2) - pow(south_stdev, 2)));
  for (int i = 0; i < states.length; i++)
    stdevs.set(states[i], sqrt(pow(stdevs.get(states[i]), 2) - pow(natl_stdev, 2)));

  // generate the final results!
  for (int i = 0; i < states.length; i++) {
    results.set(states[i], exps.get(states[i]) + stdevs.get(states[i])*randomGaussian());
    if (results.get(states[i]) > 0)
      winner.set(states[i], 0);
    else
      winner.set(states[i], 1);
  }

  if (random(1) < 0.12f)
    winner.set("UT", 2);

  if (winner.get("ME1") == winner.get("ME2"))
    winner.set("ME", winner.get("ME1"));
  if (winner.get("NE1") == winner.get("NE2"))
    winner.set("NE", winner.get("NE1"));

  // reset the electoral votes
  clinton_score = 0;
  trump_score = 0;
  mcmullin_score = 0;
}

public void update_map() {
  String[] ET = {
    "ME", "NH", "VT", "MA", "NY", "RI", "CT", "NJ", "PA", "DE", "MD", "VA", "WV", "OH", "MI", "NC", "SC", "GA", "FL", "ME1", "ME2", "DC"
  };
  String[] CT = {
    "AL", "TN", "MS", "KY", "IN", "IL", "WI", "MN", "IA", "MO", "AR", "LA", "TX", "OK", "KS", "NE", "NE1", "NE2", "NE3"
  };
  String[] MT = {
    "ND", "SD", "MT", "WY", "CO", "NM", "UT", "AZ", "ID"
  };
  String[] PT = {
    "WA", "OR", "NV", "CA", "AK", "HI"
  };

  if (time_counter == 1) {
    show_states(ET);
    update_score_bar();
  }
  if (time_counter == 20) {
    show_states(CT);
    update_score_bar();
  }
  if (time_counter == 60) {
    show_states(MT);
    update_score_bar();
  }
  if (time_counter == 110) {
    show_states(PT);
    update_score_bar();
    write_headlines();
  }
}

public void update_score_bar() {
  textFont(pts_font);
  strokeWeight(0);
  
  // under bar
  stroke(0xffeeeeee);
  fill(0xffeeeeee);
  rect(20, 270, 918, 30);
  // clear text
  stroke(0xffffffff);
  fill(0xffffffff);
  rect(20, 250, 918, 20);

  // clinton bar
  stroke(0xff1D4780);
  fill(0xff1D4780);
  float c_len = (PApplet.parseFloat(clinton_score) / 538.0f) * 918.0f;
  rect(20, 270, c_len, 30);
  
  textAlign(LEFT);
  textSize(20);
  text(clinton_score,25,265);

  // trump bar
  stroke(0xffBD1B26);
  fill(0xffBD1B26);
  float t_len = (PApplet.parseFloat(trump_score) / 538.0f) * 918.0f;
  rect(938-t_len, 270, t_len, 30);
  
  textAlign(RIGHT);
  textSize(20);
  text(trump_score,933,265);
  
  // mcmullin bar
  stroke(0xffFFCC00);
  fill(0xffFFCC00);
  float m_len = (PApplet.parseFloat(mcmullin_score) / 538.0f) * 918.0f;
  rect(938-t_len-m_len, 270, m_len, 30);
  
  // goalpost
  PImage img = loadImage("data/goalpost.png");
  image(img,0,220);
}

public void write_headlines() {
  
  String headline = "error";
  String subh1 = "error";
  String subh2 = "error";
 
  if (clinton_score > 269) {
    headline = "MADAM PRESIDENT";
    
    if (clinton_score > 426)
      subh1 = "CLINTON SECURES WIDEST WIN SINCE REAGAN;";
    else if (clinton_score > 380)
      subh1 = "CLINTON MAKES HISTORY IN LANDSLIDE WIN;";
    else if (clinton_score > 330)
      subh1 = "CLINTON MAKES HISTORY IN DECISIVE WIN;";
    else if (clinton_score > 290)
      subh1 = "GRUELING CAMPAIGN ENDS IN CLINTON WIN;";
    else
      subh1 = "CLINTON MAKES HISTORY WITH NARROW WIN;";
    
    float seed = random(1);
    
    if (seed < 0.4f)
      subh2 = "NATION AWAITS CONCESSION FROM TRUMP";
    else if (seed < 0.6f)
      subh2 = "TRUMP CRIES \u201cRIGGED\u201d IN RAMBLING SPEECH";
    else if (seed < 0.8f)
      subh2 = "DEFLATED TRUMP GIVES BRIEF CONCESSION";
    else
      subh2 = "RIOTS BREAK OUT AS TRUMP CONCEDES RACE";
    
    if (winner.get("UT") == 2)
      subh2 = "EVAN McMULLIN TAKES UTAH IN LATE SURGE";
    if (winner.get("TX") == 0)
      subh2 = "RECORD HISPANIC TURNOUT PAINTS TEXAS BLUE";
    
  }
  
  else if (trump_score > 269) {
    headline = "TRUMP PREVAILS";
    
    if (trump_score > 320)
      subh1 = "CLINTON BASE CRUMBLES IN SHOCKING ROUT;";
    else if (trump_score > 290)
      subh1 = "UPSET VICTORY CAUSES GLOBAL SHOCKWAVES;";
    else {
      float seed = random(1);
      
      if (seed < 0.4f) {
        subh1 = "IN NARROW WIN, BILLIONAIRE COMPLETES";
        subh2 = "HOSTILE TAKEOVER OF U.S. GOVERNMENT";
      }
      
      else {
        subh1 = "CLINTON, WINNING POPULAR VOTE, FAILS TO";
        subh2 = "CONVERT POLLS IN CRUCIAL SWING STATES";
      }
    }
    
    if (subh2.equals("error")) {
      float seed = random(1);
     
      if (seed < 0.2f)
        subh2 = "\u201cSHY TRUMP\u201d VOTERS DEFY EXPECTATIONS";
      else if (seed < 0.4f)
        subh2 = "YOUNG VOTERS FAIL TO MATCH OBAMA TURNOUT";
      else if (seed < 0.6f)
        subh2 = "VIOLENCE ERUPTS ON ELECTION RESULTS";
      else if (seed < 0.8f)
        subh2 = "TRUMP EBULLIENT IN GLOATING SPEECH";
      else
        subh2 = "HIGHEST GENDER BARRIER REMAINS INTACT";
    }
    
  }
  else if (mcmullin_score > 0) {
    headline = "ELECTION DEADLOCK";
    
    subh1 = "McMULLIN WIN IN UTAH PROLONGS ELECTION;";
    subh2 = "HOUSE TO CALL RACE FOR FIRST TIME SINCE 1824";
  }
  else {
    headline = "IT'S A TIE!";
    
    subh1 = "NATION PLUNGES INTO CHAOS ON 269-269 TALLY;";
    subh2 = "HOUSE TO CALL RACE FOR FIRST TIME SINCE 1824";
  }
    
  // draw headline
  fill(0xff000000);
  textFont(headline_font);
  textAlign(CENTER);
  text(headline,479,80);
  
  // draw line
  strokeWeight(5);
  stroke(0xff000000);
  line(279,114,679,114);
  
  // draw subhS
  fill(0xff000000);
  textFont(subheadline_font);
  textAlign(CENTER);
  text(subh1,459,170);
  text(subh2,499,215);
}

public void show_states(String[] zone) {
  for (int i = 0; i < zone.length; i++) {
    String img_str = "data/" + zone[i] + "-" + winner.get(zone[i]) + ".png";
    PImage img = loadImage(img_str);
    image(img, 0, 300);

    if (winner.get(zone[i]) == 0)
      clinton_score += evs.get(zone[i]);
    if (winner.get(zone[i]) == 1)
      trump_score += evs.get(zone[i]);
    if (winner.get(zone[i]) == 2)
      mcmullin_score += evs.get(zone[i]);
  }
}

public void run_litmus_tests() {
  int N = 10000;

  IntDict hrc_win_count = new IntDict();
  for (int i = 0; i < states.length; i++)
    hrc_win_count.set(states[i], 0);
  hrc_win_count.set("electoral college", 0);
  hrc_win_count.set("popular vote", 0);

  String x_state = "NC";
  String y_state = "GA";
  float[] x_array = new float[N];
  float[] y_array = new float[N]; 

  // roll the dice
  for (int j = 0; j < N; j++) {
    gen_results();

    for (int i = 0; i < states.length; i++) {
      if (winner.get(states[i]) == 0)
        hrc_win_count.set(states[i], hrc_win_count.get(states[i]) + 1);

      if (states[i].equals(x_state))
        x_array[j] = results.get(states[i]);
      if (states[i].equals(y_state))
        y_array[j] = results.get(states[i]);
    }

    if (clinton_score > 270)
      hrc_win_count.set("electoral college", hrc_win_count.get("electoral college") + 1);
  }

  for (int i = 0; i < states.length; i++) {
    println(states[i] + "\t" + str(PApplet.parseFloat(hrc_win_count.get(states[i]))/N * 100));
  }

  //println("corr btwn " + x_state + " and " + y_state + ": " + str(corr(x_array,y_array)));
  println("EC:" + "\t" + str(PApplet.parseFloat(hrc_win_count.get("electoral college"))/N * 100));
}

public float corr(float[] xs, float[] ys) {
  float sx = 0.0f;
  float sy = 0.0f;
  float sxx = 0.0f;
  float syy = 0.0f;
  float sxy = 0.0f;

  int n = xs.length;

  for (int i = 0; i < n; ++i) {
    float x = xs[i];
    float y = ys[i];

    sx += x;
    sy += y;
    sxx += x * x;
    syy += y * y;
    sxy += x * y;
  }

  // covariation
  float cov = sxy / n - sx * sy / n / n;
  // standard error of x
  float sigmax = sqrt(sxx / n -  sx * sx / n / n);
  // standard error of y
  float sigmay = sqrt(syy / n -  sy * sy / n / n);

  // correlation is just a normalized covariation
  return cov / sigmax / sigmay;
}

public void restart() {
  gen_results();
  time_counter = 0;
  background(256, 256, 256);
  update_score_bar();
}

public void mouseClicked() {
  restart();
}

public void draw() {
  time_counter++;
  update_map();
}

public void setup() {
  size(958, 920);
  background(256, 256, 256);
  strokeWeight(0);
  restart();

  for (int i = 0; i < states.length; i++)
    evs.set(states[i], evs_array[i]);
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "election_randomizer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
